<?php 

/* Jstore Premium Theme Template */

?>

<div class="pho-premium-wrapper">

	<div class="premium-contnt">
	
		<div class="pho-premium-head">
			<h1> <?php esc_html_e( 'Jstore', 'jstore' ); ?></h1>
			<p> <?php printf( esc_html__( 'Premium', 'jstore' ) ); ?> <span> <?php printf( esc_html__( '1.0', 'jstore' ) ); ?> </span> </p>
			<a href="https://www.phoeniixx.com/product/jstore-theme/" class="button btn-buy-now" target="_blank"><?php esc_html_e( 'Buy Now - $59', 'jstore' ); ?></a>
			<a href="https://phoeniixx.com/demo/themes/jstore/" class="button live-demo" target="_blank"><?php esc_html_e( 'Live Demo', 'jstore' ); ?></a>

		</div>
		
		<div class="pho-contnt-table">
			<table cellspacing="0">
				<thead>
					<tr>
						<th><?php printf( esc_html__( 'Jstore', 'jstore' ) ); ?> <br> <?php printf( esc_html__( 'Woocommerce Theme', 'jstore' ) ); ?></th>
						<th><?php printf( esc_html__( 'Free Version', 'jstore' ) ); ?></th>
						<th><?php printf( esc_html__( 'Premium Version', 'jstore' ) ); ?></th>
					</tr>
				</thead>
				
				<tbody>
					<tr class="table-content">
						<td><?php printf( esc_html__( 'Home Page Design', 'jstore' ) ); ?></td>
						<td><?php printf( esc_html__( '1', 'jstore' ) ); ?></td>
						<td><?php printf( esc_html__( '7', 'jstore' ) ); ?></td>
					</tr>

					<tr class="table-content">
						<td><?php printf( esc_html__( 'Theme Options', 'jstore' ) ); ?></td>
						<td><i class="fa fa-check" aria-hidden="true"></i></td>
						<td><i class="fa fa-check" aria-hidden="true"></i></td>
					</tr>
					
					<tr class="table-content">
						<td><?php printf( esc_html__( 'Blog Page Design', 'jstore' ) ); ?></td>
						<td><i class="fa fa-check" aria-hidden="true"></i></td>
						<td><i class="fa fa-check" aria-hidden="true"></i></td>
					</tr>
					
					<tr class="table-content">
						<td><?php printf( esc_html__( 'Responsive Layout', 'jstore' ) ); ?></td>
						<td><i class="fa fa-check" aria-hidden="true"></i></td>
						<td><i class="fa fa-check" aria-hidden="true"></i></td>
					</tr>
					
					<tr class="table-content">
						<td><?php printf( esc_html__( 'Max Mega Menu', 'jstore' ) ); ?></td>
						<td><i class="fa fa-times" aria-hidden="true"></i></td>
						<td><i class="fa fa-check" aria-hidden="true"></i></td>
					</tr>
					
					<tr class="table-content">
						<td><?php printf( esc_html__( 'Advance Theme Options', 'jstore' ) ); ?></td>
						<td><i class="fa fa-times" aria-hidden="true"></i></td>
						<td><i class="fa fa-check" aria-hidden="true"></i></td>
					</tr>
					
					<tr class="table-content">
						<td><?php printf( esc_html__( 'Premium Quick View', 'jstore' ) ); ?></td>
						<td><i class="fa fa-times" aria-hidden="true"></i></td>
						<td><i class="fa fa-check" aria-hidden="true"></i></td>
					</tr>
					
					<tr class="table-content">
						<td><?php printf( esc_html__( 'Premium Wishlist ', 'jstore' ) ); ?></td>
						<td><i class="fa fa-times" aria-hidden="true"></i></td>
						<td><i class="fa fa-check" aria-hidden="true"></i></td>
					</tr>
					
					<tr class="table-content">
						<td><?php printf( esc_html__( 'Premium Compare', 'jstore' ) ); ?></td>
						<td><i class="fa fa-times" aria-hidden="true"></i></td>
						<td><i class="fa fa-check" aria-hidden="true"></i></td>
					</tr>
					
					<tr class="table-content">
						<td><?php printf( esc_html__( 'Site Origin Page Builder', 'jstore' ) ); ?></td>
						<td><i class="fa fa-times" aria-hidden="true"></i></td>
						<td><i class="fa fa-check" aria-hidden="true"></i></td>
					</tr>
					
					<tr class="table-content">
						<td><?php printf( esc_html__( 'Drag and Drop Banner', 'jstore' ) ); ?></td>
						<td><i class="fa fa-times" aria-hidden="true"></i></td>
						<td><i class="fa fa-check" aria-hidden="true"></i></td>
					</tr>
					
					<tr class="table-content">
						<td><?php printf( esc_html__( 'Premium Ajax Scroll', 'jstore' ) ); ?></td>
						<td><i class="fa fa-times" aria-hidden="true"></i></td>
						<td><i class="fa fa-check" aria-hidden="true"></i></td>
					</tr>
					
					<tr class="table-content">
						<td><?php printf( esc_html__( 'Premium Zoom', 'jstore' ) ); ?></td>
						<td><i class="fa fa-times" aria-hidden="true"></i></td>
						<td><i class="fa fa-check" aria-hidden="true"></i></td>
					</tr>
					
					<tr class="table-content">
						<td><?php printf( esc_html__( 'Ajax Add to Cart', 'jstore' ) ); ?></td>
						<td><i class="fa fa-times" aria-hidden="true"></i></td>
						<td><i class="fa fa-check" aria-hidden="true"></i></td>
					</tr>
					
					<tr class="table-content">
						<td><?php printf( esc_html__( 'WPML Compatible', 'jstore' ) ); ?></td>
						<td><i class="fa fa-check" aria-hidden="true"></i></td>
						<td><i class="fa fa-check" aria-hidden="true"></i></td>
					</tr>
	
					
				</tbody>
			</table>
		</div>
		
	</div>
	
</div>