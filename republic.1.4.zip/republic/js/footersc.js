(function($) {

    $(document).foundation();

})(jQuery);

