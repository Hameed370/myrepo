<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

get_header(); ?>

	<div id="primary" class="large-12 columns content-area">
		<main id="main" class="site-main" role="main">
<?php      
    
 

    //Multi Tabs
    get_template_part('template-parts/multi-tabs');
                
?>  
                </main><!-- #main -->
	</div><!-- #primary -->

<?php get_footer(); 